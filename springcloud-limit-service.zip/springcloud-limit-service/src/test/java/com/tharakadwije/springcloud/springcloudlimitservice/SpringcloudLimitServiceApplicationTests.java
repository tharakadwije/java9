package com.tharakadwije.springcloud.springcloudlimitservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudLimitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
